<template>
    <div id="app">
      <h1>--</h1>
    </div>
</template>

<script>
export default {
    name: "App",
    mounted() {
      window.Echo.private('notification')
          .listen('NotificationSend', (e) => {
            alert(e.notification);
          });
    },
}
</script>

<style>
</style>
