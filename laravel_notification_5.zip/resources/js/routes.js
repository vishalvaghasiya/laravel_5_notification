// let baseUrl = '';
//
// export default [
//     // Front End And Common Pages
//     {
//         path: '*',
//         // component: NotFoundComponent
//     },
//     {
//         path: '/',
//         name: 'Root',
//         // component: Login,
//     }
// ]


